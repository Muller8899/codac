"use client";

import GameCard from "@/components/GameCard";
import Link from "next/link";

interface GameSectionProps {
  title: string;
  games: {
    id: string;
    title: string;
    imageUrl: string;
    slug: string;
  }[];
  hasViewAll?: boolean;
  viewAllLink?: string;
}

export default function GameSection({ title, games, hasViewAll = true, viewAllLink = "#" }: GameSectionProps) {
  return (
    <div className="w-full py-6">
      <div className="container mx-auto px-4">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="section-title">{title}</h2>
          {hasViewAll && (
            <Link
              href={viewAllLink}
              className="text-sm text-primary hover:underline"
            >
              查看更多 &raquo;
            </Link>
          )}
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {games.map((game) => (
            <GameCard
              key={game.id}
              title={game.title}
              imageUrl={game.imageUrl}
              slug={game.slug}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
