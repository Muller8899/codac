"use client";

import { useParams, useRouter } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GameCard from "@/components/GameCard";
import { Button } from "@/components/ui/button";
import { popularGames, newGames, mobileGames, pcGames } from "@/data/games";

interface Game {
  id: string;
  title: string;
  imageUrl: string;
  slug: string;
}

export default function CategoryPage() {
  const params = useParams<{ slug: string }>();
  const router = useRouter();
  const slug = params.slug;

  // Map category slugs to their respective game data and titles
  const categoryMap: Record<string, { title: string; games: Game[] }> = {
    'popular': {
      title: 'POPULAR GAMES',
      games: popularGames
    },
    'new': {
      title: 'NEW GAMES',
      games: newGames
    },
    'mobile-games': {
      title: 'MOBILE GAMES (DIRECT TOP-UP)',
      games: mobileGames
    },
    'pc-games': {
      title: 'PC GAMES AND VOUCHERS',
      games: pcGames
    },
  };

  const category = categoryMap[slug];

  if (!category) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-codaPurple py-12">
          <div className="container mx-auto px-4 text-center">
            <h1 className="mb-6 text-3xl font-bold text-white">Category Not Found</h1>
            <p className="mb-8 text-white">We couldn't find the category you're looking for.</p>
            <Button onClick={() => router.push('/')}>
              Back to Home
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-codaPurple">
        <div className="container mx-auto px-4 py-8">
          <h1 className="mb-8 text-3xl font-bold text-white">{category.title}</h1>

          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {category.games.map((game) => (
              <GameCard
                key={game.id}
                title={game.title}
                imageUrl={game.imageUrl}
                slug={game.slug}
              />
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
